MIDTOWN MADNESS 2 UNOFFICIAL PATCH README

[Crash Fixes]
- Increased memory limits to prevent crashes with addons
- Fixed a crash related to sirens when a vehicle was not defined as a police car in vehicle types
- Fixed a crash when attempting to view the showcase of a vehicle that is missing a showcase image
- Disallowed hudmap toggling in a city without a hudmap, preventing a game crash
- Fixed an issue that could cause the game to crash when switching to an addon city from an official city
- Potentially fixed a crash related to collisions in CnR

[Bug Fixes]
- Fixed an issue where buildings could be improperly lit depending on the last selected TOD/Weather settings
- Fixed the issue where bridges didn't render while the game is paused
- Fixed an issue that prevented traffic cars from using their last paintjob
- Fixed an issue where the dashboard camera could freeze the HUD state to disabled in some cases
- Fixed an issue where the cop chase state was persistent between level loads, causing the incorrect music to fire
- Fixed an oversight that caused the UI music to continue playing after the chat box was closed

[Features/Tweaks]
- Enabled ambient audio while music is enabled, this will mimic the behaviour of Beta 1
- Added a limit to the amount of times a pedestrian can atttempt to update itself before it bails. Preventing a game freeze in certain cases.
- Increased max texture depth from 16 to 32
