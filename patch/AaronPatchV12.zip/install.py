from tkinter import filedialog
from tkinter import messagebox
import tkinter as tk
import sys
import subprocess

root = tk.Tk()
root.withdraw()

messagebox.showinfo("Installation Message", "Please select your Midtown Madness 2 EXE")
exepath = filedialog.askopenfilename(filetypes = [("Midtown Madness 2 Executable", "*.exe")])

# user cancel?
if len(exepath) == 0:
  sys.exit("User cancelled")
  
subprocess.call(["scripts\\UnofficialPatchInstall.bat", exepath])

root.destroy()