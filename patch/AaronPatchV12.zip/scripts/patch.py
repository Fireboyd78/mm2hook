import sys
import os


class PatchSector:
  address = 0
  bytes = []


def apply_patches(file, patches):
  filelen = os.path.getsize(file)
  fbytes = None
  with open(file, "rb") as f:
    fbytes = bytearray(f.read(filelen))
  
  # hacky overwrite
  for p in patches:
    if p.address < filelen:
      # patch
      for b in range(len(p.bytes)):
        fbytes[p.address + b] = p.bytes[b]

      print("....applied patch sector at " + str(p.address))
    else:
      print("....failed to apply patch at " + str(p.address) + ", target file too short")
      
  # rewrite
  with open(file, "wb") as f:
    f.write(fbytes)
      

def parse_patch_file(file):
  patches = []
  with open(file, "r") as f:
    for line in f:
      if line.startswith("//") or len(line) < 3:
        continue
    
      pd = line.split()

      # 2 elements minimum?
      if len(pd) < 2:
        print("failed to parse patch line: " + line + ". Invalid or empty")
        continue
        
      # parse elements
      try: 
        addr = int(pd[0], 16)
        bytes = bytearray.fromhex(pd[1])
        
        # create patch sector and fill data
        ps = PatchSector()
        ps.address = addr
        ps.bytes = bytes
        patches.append(ps)
        
      except:
        print ("error parsing patch: " + sys.exc_info()[0])
        
  # success      
  return patches
  

def main(args):
  argc = len(args)
  # echo usage if not enough args
  if argc < 2:
    sys.exit("Usage : patch <file> <patchfile>")
    
  # make sure the files exist
  for arg in range(2):
    if not os.path.isfile(args[arg]):
      sys.exit(args[arg] + " doesn't exist!")
      
  # start the patching progress
  print("applying " + os.path.basename(args[1]) + "...")
  patches = parse_patch_file(args[1])
  
  if len(patches) == 0:
    sys.exit("Empty or incorrect patch file")
    
  # apply patches  
  apply_patches(args[0], patches)
  
  # this looked ugly :P
  # print("complete")
  
if __name__ == "__main__":
  main(sys.argv[1:])