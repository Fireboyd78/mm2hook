import sys
import os
import hashlib

def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

    
def main(args):
  argc = len(args)
  # echo usage if not enough args
  if argc < 2:
    sys.exit("Usage : hashcheck <file> <comparehash>")
    
  # make sure the file exists
  if not os.path.isfile(args[0]):
    sys.exit(args[0] + " doesn't exist!")
      
  # check hashes
  if not md5(args[0]) == args[1]:
    print("WARNING : The hash for " + args[0] + " does not match!")

    
if __name__ == "__main__":
  main(sys.argv[1:])