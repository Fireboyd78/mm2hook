import sys
import os


class PatchSector:
  file = ""
  address = 0
  bytes = []


def parse_patch_file(file):
  patches = []
  with open(file, "r") as f:
    for line in f:
      if line.startswith("//") or len(line) < 3:
        continue
    
      pd = line.split()

      # 2 elements minimum?
      if len(pd) < 2:
        print("failed to parse patch line: " + line + ". Invalid or empty")
        continue
        
      # parse elements
      try: 
        addr = int(pd[0], 16)
        bytes = bytearray.fromhex(pd[1])
        
        # create patch sector and fill data
        ps = PatchSector()
        ps.address = addr
        ps.bytes = bytes
        ps.file = file
        patches.append(ps)
        
      except:
        print ("error parsing patch: " + str(sys.exc_info()[0]))
        
  # success      
  return patches
  

def main(args):
  argc = len(args)
  # echo usage if not enough args
  if argc < 1:
    sys.exit("Usage : patch <file1> <file2> etc")
    
  # make sure the files exist
  for arg in range(argc):
    if not os.path.isfile(args[arg]):
      sys.exit(args[arg] + " doesn't exist!")
      
  # start the patching progress
  patches = []
  for arg in args:
    plst = parse_patch_file(arg)
    for patch in plst:
      patches.append(patch)
  
  # conpute overlap
  for p1 in patches:
    for p2 in patches:
      # no :|
      if p1.file == p2.file:
        continue
      
      # compute overlap
      p1start = p1.address
      p2start = p2.address
      p1len = len(p1.bytes)
      p2len = len(p2.bytes)
      if p2start >= p1start and (p2start + p2len) <= (p1start + p1len):
        print(p1.file + " and " + p2.file + " overlap!")
      
  
  if len(patches) == 0:
    sys.exit("No patches found")

  print("If there is no output there is no overlap :)")

if __name__ == "__main__":
  main(sys.argv[1:])